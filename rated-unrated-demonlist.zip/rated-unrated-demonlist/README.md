# Rated+Unrated Demonlist

A free, dark-themed, static Geometry Dash community level database built with plain HTML, CSS, JavaScript, and JSON. It is designed as a starting point for tracking rated and unrated levels, community rankings, records, and player leaderboards.

## Features

- Responsive dark UI with custom branding
- Main rankings and searchable all-level database
- Filters for community difficulty, official rating status, and list category
- Individual level profile dialogs
- Local record entry and a player leaderboard
- Local level submissions
- Export of the local database as JSON
- No frameworks, build tools, API keys, or paid services required

## Important limitations

This is a working **static starter**, not a multi-user service. Records, submissions, and edits are stored in the current browser's `localStorage`; they are not shared with visitors and there is no secure moderator/admin login. The sample entries in `data.js` are illustrative placeholders, not factual rankings. Replace them with verified data before public launch.

## Run locally

1. Keep `index.html`, `style.css`, `data.js`, and `app.js` in the same folder.
2. Open `index.html` in a modern browser.
3. If your browser restricts local-file behavior, run a simple local server from this folder:
   - Python: `python3 -m http.server 8000`
   - Then open `http://localhost:8000`

## Publish free with GitHub Pages

1. Sign in to GitHub and create a new **public** repository, for example `rated-unrated-demonlist`.
2. Upload `index.html`, `style.css`, `data.js`, `app.js`, and `README.md` to the repository root.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then save.
6. Wait for the deployment to finish. GitHub will show the public website URL in Settings → Pages.

Your URL will usually resemble `https://YOUR-USERNAME.github.io/rated-unrated-demonlist/`. Use the exact URL GitHub gives you.

## Edit the level database

Open `data.js` and update the `levels` array. Each level follows this shape:

```js
{
  id: "unique-internal-id",
  name: "Level Name",
  creator: "Creator Name",
  levelId: "12345678",
  officialStatus: "Unrated", // Rated, Unrated, or Legacy
  difficulty: "Extreme Demon",
  verification: "Verified", // or Unverified
  listStatus: "Mainlist", // Mainlist, Extended, Legacy, Challenge
  rank: 1,
  bestRecord: 100,
  notes: "Source links or moderation notes"
}
```

Use unique internal `id` values. `rank` is the community ranking, not the official in-game rating. `officialStatus` and `difficulty` intentionally remain separate.

Records are objects in the `records` array with `player`, `levelId` (the level's internal ID), `percent`, `proof`, `status`, and `date`. Only records with `status: "Approved"` contribute to the leaderboard.

## Backups and browser storage

The submission page's **Export database JSON** button downloads a backup of the current browser's data. It does not automatically update `data.js` or GitHub. If you clear browser data, local entries can be lost, so export backups regularly.

## Before opening submissions to the public

For a real community-operated list, add a shared database and server-side validation, moderator roles, proof review, rate limiting, and a published ranking policy. Do not put private credentials or database admin keys in front-end JavaScript. A static GitHub Pages site alone cannot safely provide shared user accounts or public writes.

## Disclaimer

This is an independent fan-made project and is not affiliated with RobTop Games or any official Geometry Dash Demonlist. Geometry Dash and its level data belong to their respective owners and creators.
